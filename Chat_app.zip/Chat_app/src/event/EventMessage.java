/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package event;

import model.Model_Message;

/**
 *
 * @author mrtru
 */
public interface EventMessage {
    public void callMessage(Model_Message message);
}
